echo Hello! I am Bash!
echo -n Your current working directory is:
pwd
echo
echo The contents of this directory are:
ls
echo
echo Have a nice day!