#! /bin/bash
cd tests/test-utils/p2a-test
ls
